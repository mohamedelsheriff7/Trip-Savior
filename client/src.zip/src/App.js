// src/App.js
import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Login from "./components/Login";
import Profile from "./components/Profile";
import CreateProfile from "./components/CreateProfile"; 
import ProfileCreationSuccess from "./components/ProfileCreationSuccess";
import ReadTourGuideProfile from "./components/ReadTourGuideProfile";
import UpdateTourGuideProfile from "./components/UpdateTourGuideProfile";
import CreateItinerary from "./components/CreateItinerary"; 
import ReadItinerary from "./components/ReadItinerary";
import Registration from "./components/Registration"; // Import the Registration component
import LandingPage from "./components/LandingPage";
import SelectRole from "./components/SelectRole";
import SellerLogin from './components/SellerLogin';
import SellerProfile from "./components/SellerProfile";
import CreateSellerProfile from "./components/CreateSellerProfile"; // Adjust according to your component
import CreateSellerSuccess from "./components/CreateSellerSuccess";
import ItineraryView from "./components/ItineraryView";
import ReadSellerProfile from './components/ReadSellerProfile';
import UpdateSellerProfile from "./components/UpdateSellerProfile";
const App = () => {
  return (
    <Router>
      <Routes>
      <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/create-profile" element={<CreateProfile />} />
        <Route path="/profile-creation-success" element={<ProfileCreationSuccess />} />
        <Route path="/read-tour-guide-profile" element={<ReadTourGuideProfile />} />
        <Route path="/update-tour-guide-profile" element={<UpdateTourGuideProfile />} />
        <Route path="/create-itinerary" element={<CreateItinerary />} />
        <Route path="/read-itinerary" element={<ReadItinerary />} />
        <Route path="/register" element={<Registration />} />  {/* Add this line for the registration route */}
        <Route path="/select-role" element={<SelectRole />} />
        <Route path="/seller-login" element={<SellerLogin />} />
        <Route path="/seller-profile" element={<SellerProfile />} />
        <Route path="/create-seller-profile" element={<CreateSellerProfile />} />
        <Route path="/create-seller-success" element={<CreateSellerSuccess />} />
        <Route path="/view_itinerary" element={<ItineraryView />} />
        <Route path="/read-seller-profile" element={<ReadSellerProfile />} />
        <Route path="/update-seller-profile" element={<UpdateSellerProfile />} />
        
      </Routes>
    </Router>
  );
};

export default App;
