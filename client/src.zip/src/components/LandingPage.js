// src/components/LandingPage.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import backgroundImage from '../images/36a01308-6ba3-4f0c-a825-93ac78c0966d.jpeg'; // Ensure this path is correct

const LandingPage = () => {
  const navigate = useNavigate();

  const handleSignup = () => {
    navigate('/register'); // Redirects to the Registration page
  };

  const handleLogin = () => {
    navigate('/select-role'); // Redirects to the Select Role page
  };

  return (
    <div style={{ ...styles.container, backgroundImage: `url(${backgroundImage})` }}>
      <div style={styles.buttonContainer}>
        <AnimatedButton onClick={handleSignup}>Signup</AnimatedButton><br>
        </br>
       <br></br> <AnimatedButton onClick={handleLogin}>Login</AnimatedButton>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-end', // Align items to the bottom
    alignItems: 'flex-end', // Align items to the right
    height: '100vh',
    backgroundSize: 'cover', // Cover the entire area
    backgroundPosition: 'center', // Center the image
    backgroundRepeat: 'no-repeat', // Prevent the image from repeating
    padding: '20px', // Add some padding to the container
  },
  buttonContainer: {
    display: 'flex',
    gap: '20px',
    marginBottom: '30px',
    marginRight:"540px" // Move buttons up by reducing margin
  },
  button: {
    padding: '15px 30px',
    fontSize: '1em',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    backgroundColor: '#808080', // Set to gray background
    color: '#fff',
    transition: 'background-color 0.3s, transform 0.3s', // Add transition for button hover
  },
  buttonHover: {
    transform: 'scale(1.1)', // Scale effect on hover
    backgroundColor: '#6c757d', // Darker shade of gray on hover
  },
};

const AnimatedButton = ({ onClick, children }) => {
  const [isHovered, setIsHovered] = React.useState(false);

  return (
    <button
      onClick={onClick}
      style={{
        ...styles.button,
        ...(isHovered ? styles.buttonHover : {}),
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {children}
    </button>
  );
};

export default LandingPage;
