// src/components/Registration.js
import React, { useState } from 'react';

const Registration = () => {
  const [role, setRole] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    mobileNumber: '',
    nationality: '',
    date_of_birth: '',
    work_status: '',
  });
  const [showFields, setShowFields] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const endpoint = {
      tourist: '/createTourist',
      tourGuide: '/registerTourGuide',
      seller: '/registerSellerReg',
      advertiser: '/registerAdvertiser',
    }[role];

    if (endpoint) {
      try {
        const response = await fetch(`http://localhost:3001${endpoint}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        });
        const data = await response.json();
        alert(data.message || data.error); // Display success or error message
      } catch (error) {
        console.error("Error:", error);
        alert('An error occurred. Please try again.');
      }
    }
  };

  const handleGoClick = () => {
    if (role) {
      setShowFields(true);
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>Register</h1>
      <div style={styles.formContainer}>
        <label htmlFor="role" style={styles.label}>Register as:</label>
        <select id="role" value={role} onChange={handleRoleChange} style={styles.select}>
          <option value="">Select a role</option>
          <option value="tourist">Tourist</option>
          <option value="tourGuide">Tour Guide</option>
          <option value="seller">Seller</option>
          <option value="advertiser">Advertiser</option>
        </select>
        <button onClick={handleGoClick} style={styles.button}>Go</button>

        {showFields && (
          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={styles.inputGroup}>
              <label htmlFor="username" style={styles.label}>Username:</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                required
                style={styles.input}
              />
            </div>

            <div style={styles.inputGroup}>
              <label htmlFor="email" style={styles.label}>Email:</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                style={styles.input}
              />
            </div>

            <div style={styles.inputGroup}>
              <label htmlFor="password" style={styles.label}>Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                required
                style={styles.input}
              />
            </div>

            {role === 'tourist' && (
              <>
                <div style={styles.inputGroup}>
                  <label htmlFor="mobileNumber" style={styles.label}>Mobile Number:</label>
                  <input
                    type="text"
                    id="mobileNumber"
                    name="mobileNumber"
                    value={formData.mobileNumber}
                    onChange={handleChange}
                    required
                    style={styles.input}
                  />
                </div>
                <div style={styles.inputGroup}>
                  <label htmlFor="nationality" style={styles.label}>Nationality:</label>
                  <input
                    type="text"
                    id="nationality"
                    name="nationality"
                    value={formData.nationality}
                    onChange={handleChange}
                    required
                    style={styles.input}
                  />
                </div>
                <div style={styles.inputGroup}>
                  <label htmlFor="date_of_birth" style={styles.label}>Date of Birth:</label>
                  <input
                    type="date"
                    id="date_of_birth"
                    name="date_of_birth"
                    value={formData.date_of_birth}
                    onChange={handleChange}
                    required
                    style={styles.input}
                  />
                </div>
                <div style={styles.inputGroup}>
                  <label htmlFor="work_status" style={styles.label}>Work Status:</label>
                  <input
                    type="text"
                    id="work_status"
                    name="work_status"
                    value={formData.work_status}
                    onChange={handleChange}
                    required
                    style={styles.input}
                  />
                </div>
              </>
            )}

            <button type="submit" style={styles.submitButton}>Submit</button>
          </form>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    padding: '20px',
    backgroundColor: '#f9f9f9',
    borderRadius: '10px',
    boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
  },
  header: {
    textAlign: 'center',
    marginBottom: '20px',
  },
  formContainer: {
    display: 'flex',
    flexDirection: 'column',
  },
  label: {
    marginBottom: '5px',
    fontWeight: 'bold',
  },
  select: {
    marginBottom: '15px',
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#007bff',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    marginBottom: '20px',
    transition: 'background-color 0.3s',
  },
  buttonHover: {
    backgroundColor: '#0056b3',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    marginTop: '20px',
  },
  inputGroup: {
    marginBottom: '15px',
  },
  input: {
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ccc',
    width: '100%',
  },
  submitButton: {
    padding: '10px 20px',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
};

export default Registration;
