import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import styles from "../styles/Profile.module.css"; // Updated import for CSS module
import travel1 from "../images/image_1.jpeg"; // Import your images
import travel2 from "../images/image_2.jpeg";
import travel3 from "../images/image3.jpeg";
import travel4 from "../images/image_4.jpeg";

const Profile = () => {
  const navigate = useNavigate();
  const location = useLocation(); // Use useLocation to get the passed state
  const { username, email, password, age, mobileNumber, years_of_experience, previous_work, work_status } = location.state || {}; // Destructure the state

  const handleCreate = () => {
    navigate("/create-profile");
  };

  const handleRead = () => {
    navigate("/read-tour-guide-profile", { state: { username, email, password, age, mobileNumber, years_of_experience, previous_work, work_status } });
  };

  const handleUpdate = () => {
    navigate("/update-tour-guide-profile", { state: { username, email, password, age, mobileNumber, years_of_experience, previous_work, work_status } });
  };

  // Add a new handler for creating an itinerary
  const handleCreateItinerary = () => {
    navigate("/create-itinerary"); // Make sure this route is defined in your Router
  };
  
  const handleReadItinerary = () => {
    navigate("/read-itinerary"); // Make sure this route is defined in your Router
  };

  // New handler for viewing itineraries
  const handleViewMyItineraries = () => {
    navigate("/view_itinerary"); // Update this route based on your application
  };
  return (
    <div className={styles.container}>
      {/* Left image column */}
      <div className={styles.imageColumn}>
        <img src={travel1} alt="Travel 1" />
        <img src={travel2} alt="Travel 2" />
        <img src={travel3} alt="Travel 3" />
        <img src={travel4} alt="Travel 4" />
      </div>
      {/* Right profile section */}
      <div className={styles.mainContent}>
        <h3 className={styles.header}>Profile Page</h3>
        <div className={styles.buttonContainer}>
          <button className={`${styles.btn} ${styles.btnSuccess}`} onClick={handleCreate}>
            Create Profile
          </button>
          <button className={`${styles.btn} ${styles.btnInfo}`} onClick={handleRead}>
            Read Profile
          </button>
          <button className={`${styles.btn} ${styles.btnWarning}`} onClick={handleUpdate}>
            Update Profile
          </button>
          <button className={`${styles.btn} ${styles.btnPrimary}`} onClick={handleCreateItinerary}>
            Create Itinerary
          </button>
          <button className={`${styles.btn} ${styles.btnSecondary}`} onClick={handleReadItinerary}>
            Read Itinerary
          </button>
          <button className={`${styles.btn} ${styles.btnSecondary}`} onClick={handleViewMyItineraries}>
            View My Itineraries
          </button>
        </div>
      </div>
    </div>
  );
};

export default Profile;
