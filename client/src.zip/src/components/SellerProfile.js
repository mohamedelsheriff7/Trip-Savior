import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import styles from "../styles/Profile.module.css"; // Updated import for CSS module
import travel1 from "../images/image_1.jpeg"; // Import your images
import travel2 from "../images/image_2.jpeg";
import travel3 from "../images/image3.jpeg";
import travel4 from "../images/image_4.jpeg";

const SellerProfile = () => {
  const navigate = useNavigate();
  const location = useLocation(); // Use useLocation to get the passed state
  const { username, email } = location.state || {}; // Destructure the state

  const handleCreate = () => {
    navigate("/create-seller-profile");
  };

  const handleRead = () => {
    navigate("/read-seller-profile", { state: { username, email } });
  };

  const handleUpdate = () => {
    navigate("/update-seller-profile", { state: { username, email } });
};


  return (
    <div className={styles.container}>
      {/* Left image column */}
      <div className={styles.imageColumn}>
        <img src={travel1} alt="Travel 1" />
        <img src={travel2} alt="Travel 2" />
        <img src={travel3} alt="Travel 3" />
        <img src={travel4} alt="Travel 4" />
      </div>
      {/* Right profile section */}
      <div className={styles.mainContent}>
        <h3 className={styles.header}>Seller Profile Page</h3>
        <div className={styles.buttonContainer}>
          <button className={`${styles.btn} ${styles.btnSuccess}`} onClick={handleCreate}>
            Create Profile
          </button>
          <button className={`${styles.btn} ${styles.btnInfo}`} onClick={handleRead}>
            Read Profile
          </button>
          <button className={`${styles.btn} ${styles.btnWarning}`} onClick={handleUpdate}>
            Update Profile
          </button>
        </div>
      </div>
    </div>
  );
};

export default SellerProfile;
